from exam_gen import *

class MatrixQuestion(LatexDoc, MultipleChoiceQuestion):


    # We're using the nicematrix package to add column labels to our matrix.
    settings.latex.header_includes = r'''
    \usepackage{nicematrix}
    '''

    # Core problem text
    body.text = r'''
    Which pairs of columns on the following matrix are \emph{not} independent?

    \NiceMatrixOptions{code-for-first-row= \color{blue}}
    $$\begin{bNiceMatrix}[first-row]
    C_0 & C_1    & C_2 & C_3 & C_4 \\
    {% for r in range(0,4) -%}
    {%- for c in range(0,5) -%}{{ matrix[c][r] }}
    {%- if not loop.last %} & {% endif %}{% endfor %} \\
    {% endfor %}
    \end{bNiceMatrix}$$

    Choose the single best option.
    '''

    def user_setup(self, rng, ctxt):
        return self.gen_matrix_data(rng)

    def gen_matrix_data(self, rng):
        # Generate some independent cols
        i_cols = [[rng.randint(-20,20) for _ in range(0,4)] for _ in range(0,3)]
        # Pick a few columns for our output matrix
        o_base = rng.sample([0,0,1,1,2], k=5)
        mults = list(range(-3,4))
        mults.remove(0)
        const_mul = lambda : rng.sample(mults,k=1)
        o_cols = [[c * j for j in i_cols[i]] for i in o_base for c in const_mul()]
        # Get our two pairs of dependent columns
        c_ans = [[c for c in range(0,5) if o_base[c] == i] for i in [0,1]]
        # Make an incorrect answer
        i_ans = rng.sample(range(0,5),2)
        while (i_ans in c_ans):
            i_ans = rng.sample(range(0,5),2)
        # return all that info
        return {
            'matrix': o_cols,
            'dependent_cols': c_ans,
            'independent_col': i_ans
            }

    # Set the style of grade appropriately
    settings.grade.style = "all_correct"

    choice.total_number = 5

    # Set the default text for all choices
    choice.text = r'''
    $C_{{ dependent_cols[index][0] }}$ and $C_{{ dependent_cols[index][1] }}$
    '''

    # Set individual choices that the default isn't good for
    choice[2].text = r'''
    $C_{{ independent_col[0] }}$ and $C_{{ independent_col[1] }}$
    '''

    # We can use the `choice_letters` variable to refer to other choices
    choice[3].text = r'''
    Both {{ choice_letters[0] }} and {{ choice_letters[1] }}.
    '''
    choice[3].is_correct = True

    choice[4].text = r'''
    All of the above
    '''

    # Chose which options to shuffle, leave others in their place
    settings.grade.shuffle = [0,1,2]
