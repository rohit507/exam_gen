from exam_gen import *
from .functions import *

class GraphQuestion(LatexDoc, Question):
    metadata.name = "Graph Question"

    body['exam'].text = r'''
    Sketch the polynomial on this graph:

    \includegraphics[width=\textwidth]{empty_grid.png} \\ ~ \\
    '''

    body['solution'].text = r'''
    Sketch the polynomial on this graph:

    \includegraphics[width=\textwidth]{solution.png} \\ ~ \\
    '''

    settings.assets = ["empty_grid.png"]

    def user_setup(self, ctxt, rng, **kwargs):

        # Grabs the polynomial from `ctxt` and plots it
        make_poly_graph("solution.png",ctxt['raw_poly'])
