from functools import reduce
from itertools import zip_longest, dropwhile

# multiplies a polynomial by x^n
mul_x = lambda p, n: ([0] * n) + p
# multiples a polynomial by a constant
mul_c = lambda p, c: [c * i for i in p]
# sums two polynomials together
sum_p = lambda a, b: [i + j for (i,j) in zip_longest(a,b, fillvalue=0)]
# trims a polynomial of extraneous zeroes
trim_p = lambda l: reversed(list(dropwhile(lambda x: x == 0, reversed(l))))
# multiply polynomials together
mul_p = lambda a, b: reduce(sum_p,[mul_x(mul_c(a,c),d)for(d,c)in enumerate(b)])
# take a zero and give us the corresponding polynomial factor
fact_z = lambda z: [- z, 1]
# take a list of zeros and produce the polynomial
prod_z = lambda zs: list(trim_p(reduce(mul_p, map(fact_z, zs))))
# find the derivative of a polynomial
deriv_p = lambda p: list(map(lambda e : e[0] * e[1], enumerate(p)))[1:]
# evaluate a polynomial at a point
eval_p = lambda p, x: sum(map(lambda e : e[1] * (x ** e[0]), enumerate(p)))

import numpy as np
import matplotlib.pyplot as plt


def make_poly_graph(out_file, *polys, bound=8, ticks=2):

    fig = plt.figure()
    ax = fig.subplots()
    x = np.linspace(bound, -bound, 100)
    for poly in polys:
        y = eval_p(poly, x)
        ax.plot(x,y)

    ax.set_xlim(-bound,bound)
    ax.set_ylim(-bound,bound)
    ax.set_xticks(range(-bound+ticks,bound,ticks))
    ax.set_yticks(range(-bound+ticks,bound,ticks))

    ax.spines.left.set_position('center')
    ax.spines.right.set_color('none')
    ax.spines.bottom.set_position('center')
    ax.spines.top.set_color('none')
    ax.xaxis.set_ticks_position('bottom')
    ax.yaxis.set_ticks_position('left')

    ax.grid(linestyle='--')
    ax.minorticks_on()

    fig.savefig(out_file)
