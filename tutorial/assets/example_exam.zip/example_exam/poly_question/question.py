from exam_gen import *
from .functions import *
from .graph_question import *
from .factor_question import *
from fractions import Fraction
from math import floor
import numpy

class PolyQuestion(LatexDoc, Question):
    metadata.name = "Polynomial Question"

    body.text = r'''
    For the following polynomial:

    $$
    {%- for term in poly -%}
      {%- if not loop.first -%}{{term.sign}}{%- endif -%}
      { {{term.num}}{%- if term.degree != 0 -%}x{%- endif -%} }
      {%- if term.degree > 1 -%}^{ {{term.degree}} }{%- endif -%}
    {%- endfor -%}
    $$
    '''

    questions = {
        'graph': GraphQuestion,
        'factors': FactorQuestion
    }

    def user_setup(self,ctxt , rng, **kwargs):

        # Make a list of 4 random integers, the zeros of our polynomial
        zeros = list(map(lambda _: rng.randint(-5,5), range(0,4)))

        # The polynomial such that each index is the coefficient of the
        # corresponding term.
        # (i.e. the polynomial is `poly[0] + poly[1]x + poly[2]x^2 ...` for a
        # given list `poly`)
        base_poly = prod_z(zeros)

        # get the highest magnitude term between the zeroes by going through
        # the different points in the base poly
        samples = numpy.linspace(min(zeros), max(zeros), 100)
        max_val = max(map(lambda n: abs(eval_p(base_poly,n)), samples))

        # Find a scaling factor that both looks nice and isn't a pain to use
        d_limit = 4
        scale = 0
        while scale == 0:
            scale = Fraction(7 / max_val).limit_denominator(d_limit)
            if scale * max_val > 7.5:
                scale = Fraction(scale.numerator - 1, scale.denominator)
            d_limit += 2

        # scale the polynomial appropriately
        poly = mul_c(base_poly, scale)

        # Reorder the terms so the highest degree is first, and split it out
        # to make the templates easier to write.
        print_poly = list()
        for (degree, coeff) in reversed(list(enumerate(poly))):
            if coeff != 0:
                print_poly.append({
                      'degree': degree,
                      'coefficient': coeff,
                      'sign': "-" if coeff < 0 else "+",
                      'num': abs(coeff)
                    })


        return {
            'poly': print_poly,
            'raw_poly': poly, # using the worse name here because the templates
                              # don't need more clutter
            'zeros': zeros
        }
