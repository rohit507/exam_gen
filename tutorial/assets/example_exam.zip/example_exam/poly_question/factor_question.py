from exam_gen import *
from .functions import *

class FactorQuestion(LatexDoc, Question):
    metadata.name = "Polynomial Factors"

    body.text = r'''
    What are its factors?
    '''

    solution.file = "factor_solution.jn2.tex"

    def user_setup(self, ctxt, rng, **kwargs):

        # Format the factors so that they're also easier to print
        print_factors = dict()

        # the `zeros` value returned by the parent question is found here
        # in the `ctxt` parameter under `ctxt['zeroes']`
        for z in ctxt['zeros']:
            if z not in print_factors:
                print_factors[z] = {
                      'zero': z,
                      'degree': 1,
                      'has_term': z != 0, # do we even print a constant term?
                      'sign': "+" if z < 0 else "-",
                      'num': abs(z)
                    }
            else:
                print_factors[z]['degree'] += 1

        return {"factors": print_factors}
