import numpy as np
import matplotlib.pyplot as plt

fig = plt.figure()
ax = fig.subplots()
rng = 8
ticks = 2

x = np.linspace(-rng,rng, 100)
y = x**4 + (10 * x**3) + (24 * x**2) - (10 * x) - 25

ax.plot(x,y / 8)

ax.set_xlim(-rng,rng)
ax.set_ylim(-rng,rng)
ax.set_xticks(range(-rng+ticks,rng,ticks))
ax.set_yticks(range(-rng+ticks,rng,ticks))

ax.spines.left.set_position('center')
ax.spines.right.set_color('none')
ax.spines.bottom.set_position('center')
ax.spines.top.set_color('none')
ax.xaxis.set_ticks_position('bottom')
ax.yaxis.set_ticks_position('left')

ax.grid(linestyle='--')
ax.minorticks_on()

fig.savefig("sample_grid.png")
