import attr

@attr.s
class Var():
    name = attr.ib()

    def eval(self, vars):
        return _eval_exp(vars.get(self.name, self), vars)

    def print_tex(self):
        return r'\mathit{\mathsf{%s}}' % self.name

    def is_complex(self):
        return False

@attr.s
class Not():
    exp = attr.ib()

    def __init__(self, e):
        self.__attrs_init__(e)

    def eval(self, vars):
        val = _eval_exp(self.exp,vars)
        if isinstance(val, bool):
            return not val
        elif isinstance(val, Not):
            return val.exp
        else:
            return val

    def print_tex(self):
        return  r'\neg{%s}' % _print_wrap_tex(self.exp)

    def is_complex(self):
        return False

@attr.s(init=False)
class And():
    exps = attr.ib()

    def __init__(self, *cmpnts):
        self.__attrs_init__(cmpnts)

    def eval(self, vars):
        result = list()
        for exp in self.exps:
            val = _eval_exp(exp, vars)
            if isinstance(val, bool):
                if val == False:
                    return False
            elif isinstance(val, And):
                result += val.exps
            else:
                result.append(val)
        return result if len(self.exps) != 0 else True


    def is_complex(self):
        return len(self.exps) > 1

    def print_tex(self):
        if len(self.exps) == 0:
            return _print_tex(True)
        elif len(self.exps) == 1:
            return _print_tex(self.exps[0])
        else:
            return r' \wedge '.join(map(_print_wrap_tex, self.exps))


@attr.s(init=False)
class Or():
    exps = attr.ib()

    def __init__(self, *cmpnts):
        self.__attrs_init__(cmpnts)

    def eval(self, vars):
        result = list()
        for exp in self.exps:
            val = _eval_exp(exp, vars)
            if isinstance(val, bool):
                if val == True:
                    return True
            elif isinstance(val, Or):
                result += val.exps
            else:
                result.append(val)
        return result if len(self.exps) != 0 else False

    def is_complex(self):
        return len(self.exps) > 1

    def print_tex(self):
        if len(self.exps) == 0:
            return _print_tex(False)
        elif len(self.exps) == 1:
            return _print_tex(self.exps[0])
        else:
            return r' \vee '.join(map(_print_wrap_tex,self.exps))

def _eval_exp(exp, vars):
    if isinstance(exp, bool):
        return exp
    else:
        exp.eval(vars)

def _print_tex(exp):
    if isinstance(exp, bool):
        return r'\mathsf{\mathit{%s}}' % ("True" if exp else "False")
    else:
        return exp.print_tex()

def _print_wrap_tex(exp):
    if isinstance(exp, bool):
        return _print_tex(exp)
    elif exp.is_complex():
        return r'\left(%s\right)' % _print_tex(exp)
    else:
        return _print_tex(exp)
