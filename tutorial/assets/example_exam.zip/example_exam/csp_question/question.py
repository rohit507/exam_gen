from exam_gen import *
from .exp import *

# Problem Variables
w = Var("w")
x = Var("x")
y = Var("y")
z = Var("z")

vars = [w,x,y,z]

# Problem Constraints
exps = [ Not(w),
         Or(x, Not(w)),
         And(w, Not(Or(x, Not(z))), Or(y, z)),
         Or(And(x, Not(w), y, Not(z)), And(Not(x), Not(y))),
         And(Or(x, w, Not(y), Not(z)), Or(Not(w), z, y), Or(Not(x), w, y)),
         Or( Not(w), x, And(z, Not(w))),
         Or(y, Not(x))
       ]

class CspQuestion(LatexDoc, MultipleChoiceQuestion):

    body.text = r'''
    From the options below choose:
    \begin{itemize}
      \item An assignment for \emph{every} variable
      \item At least two constraints
    \end{itemize}

    Such that all chosen constraints are satisfied.

    Extra credit points will be awarded for every constraint above 2 that is
    chosen, but no points will be awarded if even a single chosen constraint
    is not satisfied by the given assignment.
    '''

    # No need to shuffle this problem
    settings.grade.shuffle = False

    # Alternate template so question will render on a single page.
    settings.template.embedded = "small_text.jn2.tex"

    # Due to our custom grading function we won't mark any choices as
    # correct, so we need to supress the check to ensure at least one
    # correct choice
    settings.grade.supress_correct_choice_error = True

    def user_setup(self, rng, ctxt):

        # When working with a question's choices or settings at runtime
        # (inside the `user_setup` or other funtions) you can't refer to
        # them directly, instead they're all properties of `self`.
        # See how we use `self.choice` here instead of just `choice`.
        self.choice.total_number = 2 * len(vars) + len(exps)

        choice_exps = dict()

        # Generate choices for each variable assignment
        for (i, v) in enumerate(vars):
            self.choice[2*i].text = r'Variable: $%s$' % (v.print_tex())
            self.choice[2*i + 1].text = r'Variable: $%s$' % (Not(v).print_tex())
            choice_exps |= {2*i: v,2*i+1: Not(v)}

        exp_start = 2 * len(vars)

        # Generate choices for each boolean expression
        for (i, e) in enumerate(exps):
            self.choice[exp_start + i].text = r' Constraint: $%s$' % (
                e.print_tex())
            choice_exps[exp_start + i] = e

        # Return the expressions (for use in `calculate_grade`)
        return {'choice_exps': choice_exps }

    # Specify that we'll be using a custom grading function
    settings.grade.style = "custom"

    # We will award between 0 and 2 points for this problem
    settings.grade.max_points = 2

    def calculate_grade(self, ctxt, is_selected):
        # Extract assignments from student choices
        assignments = dict()
        for i in range(0, 2 * len(vars)):
            assignment = ctxt['choice_exps'][i]
            if is_selected[i] and isinstance(assignment, Var):
                assignments[assignment.name] = True
            elif is_selected[i] and isinstance(assignment, Not):
                assignments[assignment.exp.name] = False

        # Extract Constraints that students chose
        constraints = list()
        for i in range(2 * len(vars), 2* len(vars) + len(exps)):
            if is_selected[i]:
                constraints.append(ctxt['choice_exps'][i])

        # Calculate and return score
        if len(constraints) <= 2:
            return 0 # Not enough contraints chosen
        else:
            score = 0
            for c in constraints:
                if c.eval(assignments) == True:
                    score += 1 # Point per Satisfied Constraint
                else:
                    return 0 # Unsatisfied Constraint = 0 Points
            return score
