from exam_gen import *

class GraphQuestion(LatexDoc, MultipleChoiceQuestion):

    # Ensure we have the latex libraries we need
    settings.latex.header_includes = r"""
    \usepackage{tikz}
    \usetikzlibrary{shapes, decorations, patterns, arrows, chains,
      fit, calc, positioning}
    """

    # Set the number of points for this problem
    settings.grade.max_points = 2

    # Set the style of grade appropriately
    settings.grade.style = "percent_correct"

    # Chose which options to shuffle
    settings.grade.shuffle = True


    # Set the problem
    body.text = r'''
    We define a mask of a bipartite graph as a set of vertices in one
    bi-partition whose edges connect to \emph{all} the vertices in the
    other bi-partition.

    \begin{center}
    \begin{tikzpicture}[thick,
      every node/.style={draw, circle, fill, inner sep=1.5pt},
      shorten >= 3pt,shorten <= 3pt
    ]

    \begin{scope}[start chain=going below,node distance=7mm]
    \foreach \i in {1,2,...,6}
      \node[on chain] (l\i) [label=left: $l_\i$] {};
    \end{scope}

    \begin{scope}[xshift=4cm,yshift=-0.5cm,start chain=going below,node distance=7mm]
    \foreach \i in {1,2,...,5}
      \node[on chain] (r\i) [label=right: $r_\i$] {};
    \end{scope}

    {% for (ln, rn) in edges %}
    \draw (l{{ln}}) -- (r{{rn}});
    {% endfor %}

    \end{tikzpicture}
    \end{center}

    Which of the following options are valid masks of the above graph?
    Choose all correct answers.
    '''

    def gen_bigraph(self, rng):
        # We're just going to shuffle the vertices on a fixed bi-graph
        l_verts, r_verts = (6, 5)
        edges = [(1,2), (1,4), (2,1), (2,3), (3,5), (4,2), (4,4),
                 (5,3), (6,3), (6,4), (6,5)]
        masks = [('l',6,2,1),('l',2,4,6),('l',1,4,3),('r',2,3,5),('r',4,3,5)]
        non_masks = [('l',5,4,2), ('l',5,6,2),('r',1,4,5)]

        permute_l = {k+1:v for (k,v) in enumerate(rng.sample(range(1,l_verts+1),l_verts))}
        permute_r = {k+1:v for (k,v) in enumerate(rng.sample(range(1,r_verts+1),r_verts))}

        def permute_mask(side, a, b, c):
            permute = permute_l if side == 'l' else permute_r
            verts = sorted([permute[v] for v in [a,b,c]])
            return (side, verts[0], verts[1], verts[2])

        return {'edges': [(permute_l[l], permute_r[r]) for (l,r) in edges]
               ,'masks': [permute_mask(*m) for m in masks]
               ,'non_masks': [permute_mask(*m) for m in non_masks]
        }

    def user_setup(self, rng, ctxt):

        graph_data = self.gen_bigraph(rng)

        masks = rng.sample(graph_data['masks'], 3)
        non_masks = rng.sample(graph_data['non_masks'], 2)

        return {
            'edges': graph_data['edges'],

            # Concat correct and incorrect answers, so correct ones are in
            # indices [0,1,2] and incorrect ones are in [3,4]
            'potential_masks': masks + non_masks,
        }

    choice.total_number = 5

    choice.text = r'''
    ${% for i in [1,2,3] -%}
    {{potential_masks[index][0]}}_{{potential_masks[index][i]}}
    {%- if not loop.last -%}, {% endif -%}
    {%- endfor %}$
    '''

    for i in [0,1,2]:
        choice[i].is_correct = True

    pass
