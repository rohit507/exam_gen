from exam_gen import *

class SumQuestion(LatexDoc, Question):
    metadata.name = "Basic Addition Question"

    body['exam'].text = r'''
    Solve the following equations:

    {%- for eq in problem -%}
       $${% for v in eq.vars -%}{{ v }}
         {%- if not loop.last %} + {% endif -%}
         {%- endfor %} = \_\_$$
    {%- endfor -%}

    What is the sum of all of their answers?
    '''

    body['solution'].text = r'''
    Solve the following equations:

    {%- for eq in problem -%}
       $${% for v in eq.vars -%}{{ v }}
         {%- if not loop.last %} + {% endif -%}
         {%- endfor %} = \solution{ {{ eq.total }} }$$
    {%- endfor -%}

    What is the sum of all of their answers?
    '''

    solution.text = " The total is {{ total }}."

    def user_setup(self, rng, **kwargs):

        ctxt_vars = dict()
        ctxt_vars['problem'] = list()
        ctxt_vars['total'] = 0

        for i in range(0,10):
            sub = self.generate_question_params(rng)
            ctxt_vars['problem'].append(sub)
            ctxt_vars['total'] += sub['total']

        return ctxt_vars

    def generate_question_params(self, rng):

        result = dict()

        # How many numbers will the student have to sum up?
        num_vars = rng.randint(4,8)

        # Generate each element
        var_list = list()
        for ind in range(0, num_vars):
            var_list.append(rng.randint(0,20))

        # return the parameters for the problem
        return {'vars': var_list,
                'num_vars': num_vars,
                'total': sum(var_list)
        }
