#!/usr/bin/env -S pipenv run python3

from exam_gen import *
from addition_question import *
from poly_question.question import *
from graph_question.question import *
from matrix_question.question import *
from csp_question.question import *
from fake_class.setup import *

class NewExam(LatexDoc, Exam):

    classes = {
        'fake-class': FakeClassroom,
    }

    questions = {
        'addition-question': SumQuestion,
        'poly-question': PolyQuestion,
        'graph-question': GraphQuestion,
        'matrix-question': MatrixQuestion,
        'csp-question': CspQuestion
    }

    intro.text = r'''
    \emph{Example Exam Introduction}
    '''

    def user_setup(self, **kwargs):
        pass

if __name__ == "__main__": run_cli(globals())
