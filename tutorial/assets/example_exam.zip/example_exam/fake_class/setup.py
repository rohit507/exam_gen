
from exam_gen import *
import attr

class FakeClassroom(Classroom):

    roster = BCoursesCSVRoster.with_options(
        file_name="class-1.csv"
    )

    answers = CSVAnswers.with_options(
        file_name="exam_answers.csv",
        ident_column="sis_id",
        attempt_column="attempt",
        mapping={
            'graph-question': "Problem 3"#,
            # 'matrix-question': "Problem 4",
            # 'csp-question': "Problem 5"
        }
    )

    grades = CSVGrades.with_options(
        file_name="grades.csv",
        columns={
            'Student ID': 'student_id',
            'name': 'name',
            'Problem 1: Answer': 'addition-question.answer',
            'Problem 1: Correct Answer': 'addition-question.correct',
            'Problem 1: Total Weight': 'addition-question.total_weight',
            'Problem 1: Ungraded Points': 'addition-question.ungraded_points',
            'Problem 1: Weighted Points': 'addition-question.weighted_points',
            'Problem 1: Points': 'addition-question.points',
            'Problem 1: Percent Grade': 'addition-question.percent_grade',
            'Problem 1: Percent Ungraded': 'addition-question.percent_ungraded',
            'Problem 2A: Answer': 'poly-question.graph.answer',
            'Problem 2A: Correct Answer': 'poly-question.graph.correct',
            'Problem 2A: Total Weight': 'poly-question.graph.total_weight',
            'Problem 2A: Ungraded Points': 'poly-question.graph.ungraded_points',
            'Problem 2A: Weighted Points': 'poly-question.graph.weighted_points',
            'Problem 2A: Points': 'poly-question.graph.points',
            'Problem 2B: Answer': 'poly-question.factors.answer',
            'Problem 2B: Correct Answer': 'poly-question.factors.correct',
            'Problem 2B: Total Weight': 'poly-question.factors.total_weight',
            'Problem 2B: Ungraded Points': 'poly-question.factors.ungraded_points',
            'Problem 2B: Weighted Points': 'poly-question.factors.weighted_points',
            'Problem 2B: Points': 'poly-question.factors.points',
            'Problem 3: Answer': 'graph-question.answer',
            'Problem 3: Correct Answer': 'graph-question.correct',
            'Problem 3: Total Weight': 'graph-question.total_weight',
            'Problem 3: Ungraded Points': 'graph-question.ungraded_points',
            'Problem 3: Weighted Points': 'graph-question.weighted_points',
            'Problem 3: Points': 'graph-question.points',
            'Problem 3: Percent Grade': 'graph-question.percent_grade',
            'Problem 3: Percent Ungraded': 'graph-question.percent_ungraded',
            'Problem 4: Answer': 'matrix-question.answer',
            'Problem 4: Correct Answer': 'matrix-question.correct',
            'Problem 4: Total Weight': 'matrix-question.total_weight',
            'Problem 4: Ungraded Points': 'matrix-question.ungraded_points',
            'Problem 4: Weighted Points': 'matrix-question.weighted_points',
            'Problem 4: Points': 'matrix-question.points',
            'Problem 4: Percent Grade': 'matrix-question.percent_grade',
            'Problem 4: Percent Ungraded': 'matrix-question.percent_ungraded',
            'Problem 5: Answer': 'csp-question.answer',
            'Problem 5: Correct Answer': 'csp-question.correct',
            'Problem 5: Total Weight': 'csp-question.total_weight',
            'Problem 5: Ungraded Points': 'csp-question.ungraded_points',
            'Problem 5: Weighted Points': 'csp-question.weighted_points',
            'Problem 5: Points': 'csp-question.points',
            'Problem 5: Percent Grade': 'csp-question.percent_grade',
            'Problem 5: Percent Ungraded': 'csp-question.percent_ungraded',
            'Total Weight': 'total_weight',
            'Points': 'weighted_points',
            'Percent Correct': 'percent_grade',
            'Percent Ungraded': 'percent_ungraded'
        }
    )

# Alternate format,
#
# fake_classroom = Classroom.with_options(
#     roster = BCoursesCSVRoster.with_options(
#         file_name="class-1.csv"
#     ),
#     root_file = __file__
# )
